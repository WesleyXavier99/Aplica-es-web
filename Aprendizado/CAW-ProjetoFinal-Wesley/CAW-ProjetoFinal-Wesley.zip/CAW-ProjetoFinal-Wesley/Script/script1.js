function verificar() {
	var elemento = document.getElementById('resp');
	elemento.innerHTML = "Obrigado por participar tirando suas dúvidas, dando sugestão ou relatando alguma reclamação. Você receberá um email como resposta!"
}

function bigImg(x)
{
 	x.style.height="120%";
	x.style.width="120%";
	x.style.border="solid black 1px";
	x.style.borderRadius="20px";
	x.style.backgroundColor ="red";
}

  function normalImg(x)
{
	x.style.height="100%";
	x.style.width="100%";
	x.style.border="none";
	x.style.backgroundColor ="yellow";
}